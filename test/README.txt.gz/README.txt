This is a test. The following umlauts should be correctly rendered if the file is
transmitted with the correct charset info in the header:

Schädel,
Lötkolben,
Würgegriff,
Straßenverkehrsordnung
